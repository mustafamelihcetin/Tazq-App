﻿namespace Tazq_Frontend.Services
{
	public static class ApiConstants
	{
		public static string BaseUrl => "https://tazq-backend.onrender.com/api/";
	}
}
