using Microsoft.Maui.Controls;

namespace Tazq_Frontend.Views
{
	public partial class ForgotPasswordPage : ContentPage
	{
		public ForgotPasswordPage()
		{
			InitializeComponent();
		}
	}
}